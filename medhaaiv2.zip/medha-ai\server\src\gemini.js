// Google Gemini provider — the free-tier option.
// Get a key at https://aistudio.google.com/apikey (no credit card required).
// Plain fetch, no extra npm dependency.

export function geminiTarget() {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  if (!key) return null;
  const model = process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';
  return {
    name: 'gemini',
    label: `Google Gemini (${model})`,
    key,
    model,
    base: `https://generativelanguage.googleapis.com/v1beta/models/${model}`,
  };
}

// The free tier returns transient 429/503s and occasionally drops the connection,
// so retry a few times with backoff before surfacing the failure to the user.
async function post(url, body, label, { attempts = 3 } = {}) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    if (i > 0) await new Promise((r) => setTimeout(r, 1500 * i));
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (r.ok) return r;
      const detail = await r.text().catch(() => '');
      lastErr = new Error(`${label} request failed (${r.status}): ${detail.slice(0, 300)}`);
      if (r.status !== 429 && r.status !== 503 && r.status < 500) throw lastErr; // client error: no point retrying
    } catch (err) {
      if (err === lastErr) throw err;
      // Network-level failure (reset/DNS/TLS) — undici hides the reason in `cause`.
      const why = err?.cause?.message || err?.cause?.code || err.message;
      lastErr = new Error(`${label} connection failed: ${why}`);
    }
  }
  throw lastErr;
}

// Gemini 3.x is a thinking model: reasoning comes back as extra parts marked
// `thought: true`. Those must be dropped or they corrupt the answer (and break JSON).
function textOf(candidatePayload) {
  return (candidatePayload?.candidates?.[0]?.content?.parts || [])
    .filter((p) => p && typeof p.text === 'string' && p.thought !== true)
    .map((p) => p.text)
    .join('');
}

function parseJson(text, label) {
  const cleaned = text.replace(/^\s*```(?:json)?\s*/i, '').replace(/\s*```\s*$/, '').trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    const m = cleaned.match(/\{[\s\S]*\}/);
    if (m) {
      try { return JSON.parse(m[0]); } catch { /* fall through */ }
    }
    throw new Error(`${label} did not return valid JSON (got ${cleaned.length} chars)`);
  }
}

export async function geminiStreamChat({ system, messages, maxTokens = 1024 }, onDelta) {
  const t = geminiTarget();
  const res = await post(
    `${t.base}:streamGenerateContent?alt=sse&key=${encodeURIComponent(t.key)}`,
    {
      systemInstruction: { parts: [{ text: system }] },
      contents: messages.map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
      generationConfig: { maxOutputTokens: maxTokens },
    },
    t.label,
  );

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  let full = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop();
    for (const line of lines) {
      const s = line.trim();
      if (!s.startsWith('data:')) continue;
      const payload = s.slice(5).trim();
      if (!payload) continue;
      let json;
      try { json = JSON.parse(payload); } catch { continue; }
      const chunk = textOf(json);
      if (chunk) { full += chunk; onDelta(chunk); }
    }
  }
  return full;
}

export async function geminiStructured({ system, prompt, schema, maxTokens = 4096 }) {
  const t = geminiTarget();
  const res = await post(
    `${t.base}:generateContent?key=${encodeURIComponent(t.key)}`,
    {
      systemInstruction: {
        parts: [{
          text: `${system}\n\nReply with a single JSON object and nothing else. It must validate against this JSON Schema:\n${JSON.stringify(schema)}`,
        }],
      },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        // Thinking tokens are drawn from this same budget, so leave generous headroom
        // or long outputs (lesson plans) get cut off mid-JSON.
        maxOutputTokens: Math.min(65536, Math.max(16384, maxTokens * 3)),
        responseMimeType: 'application/json',
      },
    },
    t.label,
  );

  const json = await res.json();
  const finish = json?.candidates?.[0]?.finishReason;
  const text = textOf(json);
  if (!text) throw new Error(`${t.label} returned no content (finishReason: ${finish || 'unknown'})`);
  if (finish && finish !== 'STOP') throw new Error(`${t.label} stopped early (${finish}) — try fewer days or a shorter request`);
  return parseJson(text, t.label);
}
