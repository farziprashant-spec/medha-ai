import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import cors from 'cors';
import { assertEnv, securityHeaders, corsOptions, errorHandler, limiters, installShutdown } from './security.js';

// Refuse to start on a misconfigured or unsafe environment, before any traffic.
assertEnv();

const { authRouter } = await import('./routes/auth.js');
const { generateRouter } = await import('./routes/generate.js');
const { activeProvider } = await import('./ai.js');

const app = express();

// The number 1, not `true`: behind a PaaS ingress `true` lets clients spoof
// X-Forwarded-For, and without it every user shares the ingress IP.
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(securityHeaders);
app.use(cors(corsOptions()));
app.use(express.json({ limit: '200kb' }));
app.use('/api', limiters.ipSpray);

// Public probe: status only. Anything else here is free reconnaissance.
app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use('/api/auth', authRouter);
app.use('/api/generate', generateRouter);

// Serve the frontend for local dev (only the app files — never the server dir or .env)
const webRoot = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
app.get('/', (req, res) => res.sendFile(path.join(webRoot, 'index.html')));
for (const f of ['index.html', 'manifest.json', 'sw.js']) {
  app.get(`/${f}`, (req, res) => res.sendFile(path.join(webRoot, f)));
}
app.use('/icons', express.static(path.join(webRoot, 'icons')));

app.use(errorHandler);

const port = process.env.PORT || 8787;
const server = app.listen(port, () => {
  console.log(`Medha AI server listening on http://localhost:${port}`);
  console.log(`AI provider: ${activeProvider().label}`);
  console.log(`Mode: ${process.env.NODE_ENV === 'production' ? 'PRODUCTION' : 'development'}`);
});
installShutdown(server);
