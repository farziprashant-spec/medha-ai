# Deploy Medha AI — one public link, then an APK

The app = frontend + Node server. A zip or a static host (Netlify) only ships the
frontend, so nothing generates. Host the SERVER once (free) and one URL becomes the
complete working app for everyone.

## Step 1 — Put the code on GitHub (5 min)

1. github.com → New repository → name it `medha-ai` → Create
2. Upload this whole folder (or use GitHub Desktop / `git push`)
   - `.env` is gitignored — your key never goes to GitHub. Good.

## Step 2 — Deploy on Render (free, ~10 min)

1. render.com → sign up with your GitHub account
2. **New +** → **Web Service** → select the `medha-ai` repo
3. Settings (auto-filled if it reads render.yaml; otherwise type them):
   - Build Command: `cd server && npm install`
   - Start Command: `cd server && npm start`
   - Instance type: **Free**
4. **Environment** tab → add:
   - `GEMINI_API_KEY` = your key
   - `JWT_SECRET` = any random 32+ character string
   - `NODE_VERSION` = `22.12.0`
   - `NODE_ENV` = `development`  (guest login needs this until real login is turned back on)
5. Create Web Service → wait for the build → you get a URL like:

   **https://medha-ai.onrender.com**

That link IS the full working app — chat, lesson plans, quizzes, everything.
Share it on WhatsApp; nothing to install, works on any phone.

> Free-tier note: the server sleeps after ~15 idle minutes; the first visit after
> that takes 30–60 seconds to wake. Paid tier ($7/mo) removes the sleep.

## Step 3 — The APK (after Step 2)

Two options, both need the public URL from Step 2:

**Option A — no APK needed (fastest):** open the link in Chrome on any Android
phone → menu ⋮ → **"Add to Home screen" / "Install app"**. It installs like a real
app with the Medha icon (it is a PWA). This is what most teachers should do.

**Option B — a real .apk file to send around:**
1. Go to **pwabuilder.com**
2. Paste your Render URL → Start → **Package for stores** → **Android**
3. Download the generated package — it contains the signed **.apk**
4. Send that file on WhatsApp; phones install it like any app

The APK is a wrapper around your URL — the server must stay deployed for it to work.

## Why an offline "full working" APK is impossible

Generation needs an AI model. That runs on a server (or Google's servers via your
API key). An APK with no server behind it can show the interface but cannot
generate — same reason the shared zip could not.
