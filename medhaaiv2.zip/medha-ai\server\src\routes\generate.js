import { Router } from 'express';
import { authMiddleware } from '../auth.js';
import { streamChat, generateStructured, isDemo } from '../ai.js';
import { generateLessonPlan } from '../lesson.js';
import { generateQuiz } from '../quiz.js';
import { limiters, sanitizeContext, cleanString } from '../security.js';
import { db } from '../db.js';

export const generateRouter = Router();

const KNOWN_TYPES = new Set(['quiz', 'studyPlan', 'slides', 'lessonPlan', 'classAnalysis']);
const MAX_TURNS = 12;
const MAX_MESSAGE_CHARS = 4000;

// Chat history arrives from the client, so validate shape and cap size before it
// reaches a prompt. Teacher text is data, never instructions.
function sanitizeMessages(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .slice(-MAX_TURNS)
    .map((m) => ({ role: m.role, content: cleanString(m.content, MAX_MESSAGE_CHARS) }))
    .filter((m) => m.content.length > 0);
}

generateRouter.post('/chat', authMiddleware, limiters.generate, async (req, res) => {
  const messages = sanitizeMessages(req.body?.messages);
  const context = sanitizeContext(req.body?.context);
  if (!messages.length) {
    return res.status(400).json({ error: 'messages_required' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  // Stop paying for tokens the moment the user navigates away or hits Stop.
  const abort = new AbortController();
  req.on('close', () => abort.abort());

  try {
    const full = await streamChat({ messages, context, signal: abort.signal }, (delta) => {
      if (!res.writableEnded) res.write(`data: ${JSON.stringify({ delta })}\n\n`);
    });
    if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify({ done: true, full, demo: isDemo() })}\n\n`);
      res.end();
    }
  } catch (err) {
    if (!res.writableEnded) {
      // Never surface an upstream stack trace or URL (it can carry the API key).
      console.error('[chat]', err.message);
      res.write(`data: ${JSON.stringify({ error: 'Could not generate a reply. Please try again.' })}\n\n`);
      res.end();
    }
  }
});

generateRouter.post('/', authMiddleware, limiters.generate, async (req, res, next) => {
  const type = typeof req.body?.type === 'string' ? req.body.type : '';
  if (!KNOWN_TYPES.has(type)) return res.status(400).json({ error: 'unknown_type' });
  const context = sanitizeContext(req.body?.context);

  try {
    let result;
    if (isDemo()) result = await generateStructured({ type, context });
    else if (type === 'lessonPlan') result = await generateLessonPlan(context);
    else if (type === 'quiz') result = await generateQuiz(context);
    else result = await generateStructured({ type, context });

    try {
      db.prepare('INSERT INTO generations (user_id, type, context_json, result_json) VALUES (?, ?, ?, ?)')
        .run(req.userId, type, JSON.stringify(context), JSON.stringify(result));
    } catch (dbErr) {
      // History is nice to have; never fail a paid generation because of it.
      console.error('[generations.insert]', dbErr.message);
    }

    res.json({ result, demo: isDemo() });
  } catch (err) {
    console.error(`[generate:${type}]`, err.message);
    res.status(502).json({
      error: 'generation_failed',
      message: 'The AI service could not complete this. Your coins have been refunded — please try again.',
    });
  }
});
