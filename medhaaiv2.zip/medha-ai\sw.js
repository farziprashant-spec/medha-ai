const CACHE='medha-v24-0';
const ASSETS=['./','./index.html','./manifest.json','./icons/icon-192.png','./icons/icon-512.png',
 './icons/icon-maskable-512.png','./icons/apple-touch-icon.png','./icons/favicon-64.png','./icons/favicon-32.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys()
 .then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const req=e.request;if(req.method!=='GET')return;
 if(req.url.indexOf('/api/')!==-1)return;
 if(req.mode==='navigate'){e.respondWith(fetch(req).then(r=>{const c=r.clone();
   caches.open(CACHE).then(x=>x.put('./index.html',c));return r}).catch(()=>caches.match('./index.html')));return}
 e.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(r=>{
   if(r&&r.status===200&&r.type==='basic'){const c=r.clone();caches.open(CACHE).then(x=>x.put(req,c))}
   return r}).catch(()=>hit)))});
