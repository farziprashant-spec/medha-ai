import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { db } from './db.js';

const OTP_TTL_MINUTES = 5;
const MAX_ATTEMPTS = 5;

// Valid Indian mobile: 10 digits starting 6–9 (optionally prefixed +91 / 91).
export function normalizePhone(raw) {
  let digits = String(raw || '').replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) digits = digits.slice(2);
  if (digits.length === 11 && digits.startsWith('0')) digits = digits.slice(1);
  if (!/^[6-9]\d{9}$/.test(digits)) return null;
  return `+91${digits}`;
}

function hashCode(code) {
  return crypto.createHash('sha256').update(code).digest('hex');
}

export function generateAndStoreOtp(phone) {
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const expiresAt = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000).toISOString();
  db.prepare('INSERT INTO otp_codes (phone, code_hash, expires_at) VALUES (?, ?, ?)')
    .run(phone, hashCode(code), expiresAt);
  return code;
}

// Real SMS delivery. Pick the provider with SMS_PROVIDER=msg91|fast2sms in .env and
// set OTP_DEV_MODE=false. In dev mode the OTP is logged and returned in the response.
export async function sendOtpSms(phone, code) {
  if (process.env.OTP_DEV_MODE !== 'false') {
    console.log(`[DEV OTP] ${phone} -> ${code} (valid ${OTP_TTL_MINUTES} min)`);
    return { sent: true, dev: true };
  }

  const provider = (process.env.SMS_PROVIDER || '').toLowerCase();
  const digits = phone.replace('+', ''); // "919876543210"

  if (provider === 'msg91') {
    // https://docs.msg91.com/sms — OTP via flow API with a DLT-approved template.
    const r = await fetch('https://control.msg91.com/api/v5/flow/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', authkey: process.env.SMS_PROVIDER_API_KEY },
      body: JSON.stringify({
        template_id: process.env.MSG91_TEMPLATE_ID,
        sender: process.env.SMS_PROVIDER_SENDER_ID || 'MEDHAI',
        mobiles: digits,
        otp: code,
      }),
    });
    const body = await r.json().catch(() => ({}));
    if (!r.ok || body.type === 'error') {
      console.error('[msg91]', r.status, JSON.stringify(body).slice(0, 200));
      throw new Error('Could not send the OTP SMS. Please try again in a minute.');
    }
    return { sent: true };
  }

  if (provider === 'fast2sms') {
    // https://docs.fast2sms.com — DLT OTP route.
    const r = await fetch('https://www.fast2sms.com/dev/bulkV2', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', authorization: process.env.SMS_PROVIDER_API_KEY },
      body: JSON.stringify({
        route: 'otp',
        variables_values: code,
        numbers: digits.replace(/^91/, ''),
      }),
    });
    const body = await r.json().catch(() => ({}));
    if (!r.ok || body.return === false) {
      console.error('[fast2sms]', r.status, JSON.stringify(body).slice(0, 200));
      throw new Error('Could not send the OTP SMS. Please try again in a minute.');
    }
    return { sent: true };
  }

  throw new Error('SMS_PROVIDER must be "msg91" or "fast2sms" when OTP_DEV_MODE=false.');
}

export function verifyOtp(phone, code) {
  const row = db.prepare(
    `SELECT * FROM otp_codes WHERE phone = ? AND consumed = 0 ORDER BY id DESC LIMIT 1`
  ).get(phone);
  if (!row) return { ok: false, reason: 'no_otp' };
  if (row.attempts >= MAX_ATTEMPTS) return { ok: false, reason: 'too_many_attempts' };
  if (new Date(row.expires_at).getTime() < Date.now()) return { ok: false, reason: 'expired' };

  db.prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?').run(row.id);

  if (hashCode(code) !== row.code_hash) return { ok: false, reason: 'invalid' };

  db.prepare('UPDATE otp_codes SET consumed = 1 WHERE id = ?').run(row.id);
  return { ok: true };
}

// Verifies a Google Identity Services ID token via Google's tokeninfo endpoint.
// Requires GOOGLE_CLIENT_ID in .env so the audience can be checked.
export async function verifyGoogleIdToken(credential) {
  const r = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
  if (!r.ok) throw new Error('invalid_google_token');
  const info = await r.json();
  if (!process.env.GOOGLE_CLIENT_ID) throw new Error('GOOGLE_CLIENT_ID is not set in server/.env');
  if (info.aud !== process.env.GOOGLE_CLIENT_ID) throw new Error('google_audience_mismatch');
  if (!info.email) throw new Error('google_email_missing');
  return info; // { sub, email, email_verified, name, picture, aud, ... }
}

export function issueToken(user) {
  const secret = process.env.JWT_SECRET;
  return jwt.sign({ sub: user.id, phone: user.phone }, secret, { expiresIn: '30d' });
}

export function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing_token' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = payload.sub;
    next();
  } catch {
    return res.status(401).json({ error: 'invalid_token' });
  }
}
