// OpenAI-compatible provider (OpenAI + Azure OpenAI).
// Uses plain fetch so no extra npm dependency is needed; the Anthropic path in
// ai.js keeps using the official @anthropic-ai/sdk.

function azureTarget() {
  const key = process.env.AZURE_OPENAI_API_KEY || process.env.AZURE_API_KEY;
  const endpoint = (process.env.AZURE_OPENAI_ENDPOINT || '').replace(/\/+$/, '');
  if (!key || !endpoint) return null;
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT_NAME || process.env.AZURE_OPENAI_MODEL_NAME || 'gpt-4o';
  const version = process.env.AZURE_OPENAI_API_VERSION || '2024-02-15-preview';
  return {
    name: 'azure-openai',
    label: `Azure OpenAI (${deployment})`,
    url: `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${version}`,
    headers: { 'Content-Type': 'application/json', 'api-key': key },
    model: deployment,
  };
}

function openaiTarget() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return null;
  const base = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
  const model = process.env.OPENAI_MODEL || 'gpt-4o';
  return {
    name: 'openai',
    label: `OpenAI (${model})`,
    url: `${base}/chat/completions`,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    model,
  };
}

// Azure wins when both are configured (that is what the Medha backend does too).
export function openAiTarget() {
  return azureTarget() || openaiTarget();
}

async function post(target, body) {
  const r = await fetch(target.url, { method: 'POST', headers: target.headers, body: JSON.stringify(body) });
  if (!r.ok) {
    const detail = await r.text().catch(() => '');
    throw new Error(`${target.label} request failed (${r.status}): ${detail.slice(0, 300)}`);
  }
  return r;
}

export async function openAiStreamChat({ system, messages, maxTokens = 1024 }, onDelta) {
  const target = openAiTarget();
  const res = await post(target, {
    model: target.model,
    stream: true,
    max_tokens: maxTokens,
    messages: [{ role: 'system', content: system }, ...messages],
  });

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  let full = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop();
    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith('data:')) continue;
      const payload = t.slice(5).trim();
      if (!payload || payload === '[DONE]') continue;
      let json;
      try { json = JSON.parse(payload); } catch { continue; }
      const delta = json.choices?.[0]?.delta?.content;
      if (delta) { full += delta; onDelta(delta); }
    }
  }
  return full;
}

export async function openAiStructured({ system, prompt, schema, maxTokens = 4096 }) {
  const target = openAiTarget();
  const res = await post(target, {
    model: target.model,
    max_tokens: maxTokens,
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: `${system}\n\nReply with a single JSON object and nothing else — no markdown fence, no commentary. It must validate against this JSON Schema:\n${JSON.stringify(schema)}`,
      },
      { role: 'user', content: prompt },
    ],
  });

  const json = await res.json();
  const text = json.choices?.[0]?.message?.content || '';
  try {
    return JSON.parse(text);
  } catch {
    const m = text.match(/\{[\s\S]*\}/); // tolerate a stray fence or preamble
    if (!m) throw new Error('Model did not return valid JSON');
    return JSON.parse(m[0]);
  }
}
