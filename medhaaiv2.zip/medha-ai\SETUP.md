# Medha AI — Setup Guide

AI teaching assistant for Indian classrooms (CBSE/ICSE/State boards, Class 1–12).
Lesson plans, quizzes, chat, presentations and study plans — in 14 Indian languages.

## Run it locally (5 minutes)

Requirements: **Node.js 22 or newer** (nodejs.org)

```bash
cd server
npm install
cp .env.example .env     # then edit .env (see below)
npm run dev
```

Open **http://localhost:8787** — that's the whole app.

## The one key you need

In `server/.env`, set ONE of these (the server auto-detects it):

```
GEMINI_API_KEY=...      # free tier — get it at https://aistudio.google.com/apikey
ANTHROPIC_API_KEY=...   # console.anthropic.com
OPENAI_API_KEY=...      # platform.openai.com
```

Also set `JWT_SECRET` to any random string of 32+ characters.

With no AI key, the app still runs fully in **demo mode** (realistic sample outputs,
clearly labelled) — good for showing the product.

## Logging in (dev mode)

Out of the box, login is in dev mode:
- **Continue with Google** signs you in as a demo teacher
- **Mobile OTP**: enter any valid Indian number — the OTP is shown on screen

## Going to production

Real login and deploy safety are documented inside `server/.env.example`:
- Real SMS OTP: MSG91 or Fast2SMS account + DLT template, then `OTP_DEV_MODE=false`
- Real Google Sign-In: a Google OAuth Client ID, then `GOOGLE_DEV_MODE=false`
- Set `NODE_ENV=production` — the server **refuses to start** until dev modes are off
  and `CORS_ORIGIN` is a real allowlist. This is intentional.

## Project layout

```
index.html        the entire frontend (PWA, vanilla JS)
manifest.json     PWA manifest        sw.js   service worker
server/
  src/index.js    Express entry (serves the frontend + API)
  src/ai.js       provider routing (Anthropic / Azure / OpenAI / Gemini / demo)
  src/lesson.js   two-phase parallel lesson-plan generator
  src/quiz.js     quiz generator + validation
  src/prompts.js  chat system prompt (grade bands, subject lock)
  src/security.js rate limits, headers, validation, boot guards
  src/demo.js     sample outputs used when no AI key is set
```
