// Two-phase parallel lesson-plan generation.
//
// Phase 1 (one call)  — the FOUNDATION: overview, NCF competency progression,
//                       objectives, misconceptions, materials, and a day-by-day
//                       mapping table. That table is the contract.
// Phase 2 (N calls)   — one call PER DAY, running concurrently. Each day call gets
//                       only the chapter summary, its own row from the mapping, and
//                       the misconception list. Nothing else. That is what keeps it
//                       fast and affordable: the days never see each other's content.
//
// Modelled on the production Medha pipeline. Two deliberate departures from it:
//  * Bloom's taxonomy is NOT used. Production purged it in favour of NCF-SE 2023
//    competencies plus a Cognitive Focus tag, and so do we.
//  * We keep structured JSON rather than markdown, because the app renders day tabs,
//    period tables and exit checks as real UI, not as a wall of text.

import { callStructured, languageLine } from './ai.js';

export const LESSON_PROMPT_VERSION = 'ncf-v1';

// Fixed ladders so the plan shape is deterministic and the model does not re-invent
// the arc of the chapter on every generation.
const DAY_THEMES = ['Foundation', 'Development', 'Application', 'Advanced', 'Integration', 'Creative', 'Synthesis'];
const FOCUS_LADDER = [
  'K, C', 'K, A', 'A, AT', 'AT, C', 'A, AT, C', 'AT, V', 'K, A, AT, C, V',
];

const SYSTEM_LESSON =
  'You are an expert NCERT/CBSE curriculum designer and teacher-trainer. ' +
  'You produce classroom-ready, pedagogically sound lesson material for Indian schools. ' +
  'You never emit preamble, meta-commentary, apologies or closing remarks. ' +
  'You never leave bracketed placeholders, "TBD", or "as per chapter" in your output. ' +
  'Every example is concrete and rooted in everyday Indian life.';

const COGNITIVE_KEY =
  'Cognitive Focus codes: K = Knowledge, A = Application, C = Communication, ' +
  'AT = Analytical Thinking, V = Values. Do NOT use Bloom\'s taxonomy terms.';

const FOUNDATION_SCHEMA = {
  type: 'object',
  properties: {
    title: { type: 'string', description: 'Chapter title, spelled as NCERT names it' },
    overview: { type: 'string', description: '2-3 paragraphs: what the chapter covers, why it matters for this class, and how understanding builds across the days.' },
    ncfGoals: {
      type: 'array',
      items: { type: 'string' },
      description: 'NCF-SE 2023 curricular goals and competencies this chapter develops. Format each as "CG-n: <goal> — C-n.m: <competency>". 3 to 4 items.',
    },
    objectives: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          text: { type: 'string', description: 'Observable, measurable outcome starting with a verb' },
          cognitiveFocus: { type: 'string', description: 'One or more of K, A, C, AT, V (comma separated)' },
        },
        required: ['text', 'cognitiveFocus'],
      },
      description: '4 to 6 chapter-level learning outcomes.',
    },
    misconceptions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          myth: { type: 'string', description: 'The wrong idea in the words a student would actually say it' },
          fact: { type: 'string', description: 'The correction AND the demonstration or counter-example that dislodges it' },
        },
        required: ['myth', 'fact'],
      },
      description: '3 to 5 misconceptions real students hold about this exact chapter.',
    },
    materials: { type: 'array', items: { type: 'string' }, description: 'Teaching aids available in a low-resource Indian classroom (chalk, string, bottle caps, notebook, the NCERT textbook).' },
    dayPlan: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          day: { type: 'integer' },
          topic: { type: 'string', description: 'The specific NCERT sub-topic taught this day' },
          coreConcepts: { type: 'array', items: { type: 'string' }, description: '2-3 concepts, named precisely' },
          objective: { type: 'string', description: 'The single outcome for this day' },
          misconception: { type: 'string', description: 'Which misconception from the list above this day must address' },
          pedagogy: { type: 'string', description: 'The teaching approach for this day, e.g. "demonstration then guided inquiry"' },
        },
        required: ['day', 'topic', 'coreConcepts', 'objective', 'misconception', 'pedagogy'],
      },
    },
  },
  required: ['title', 'overview', 'ncfGoals', 'objectives', 'misconceptions', 'materials', 'dayPlan'],
};

const DAY_SCHEMA = {
  type: 'object',
  properties: {
    day: { type: 'integer' },
    topic: { type: 'string' },
    minutes: { type: 'integer' },
    objectives: { type: 'array', items: { type: 'string' }, description: '2-3 outcomes for today only.' },
    periodPlan: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          phase: { type: 'string' },
          minutes: { type: 'integer' },
        },
        required: ['phase', 'minutes'],
      },
      description: 'Introduction, Main Teaching, Classroom Activity, Guided Practice, Assessment, Homework. Minutes MUST sum to the period length.',
    },
    hook: { type: 'string', description: 'The actual words the teacher says to open the class — a demonstration, surprising fact or question from everyday Indian life.' },
    concepts: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          explanation: { type: 'string', description: '3-5 sentences of the actual explanation the teacher delivers, at this class reading level.' },
        },
        required: ['name', 'explanation'],
      },
      description: 'The 2-3 concepts taught today, with the real teaching script.',
    },
    workedExample: { type: 'string', description: 'One fully worked example with every step shown. For quantitative subjects use Given / To Find / Formula / Steps / Answer with units.' },
    boardWork: { type: 'string', description: 'Exactly what to draw or write on the blackboard, described so it can be reproduced without an image.' },
    misconceptionCheck: { type: 'string', description: 'The misconception, the sentence a student typically says, and the counter-demonstration that dislodges it.' },
    activity: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        grouping: { type: 'string', description: 'pairs / groups of 4 / whole class' },
        materials: { type: 'array', items: { type: 'string' } },
        steps: { type: 'array', items: { type: 'string' }, description: '4-6 numbered steps, each saying what the teacher does and what students do.' },
        watchFor: { type: 'array', items: { type: 'string' }, description: 'Two specific student errors to circulate and look for.' },
        support: { type: 'string', description: 'One concrete simplification for struggling learners.' },
        extension: { type: 'string', description: 'One concrete extension for advanced learners.' },
      },
      required: ['name', 'grouping', 'materials', 'steps', 'watchFor', 'support', 'extension'],
    },
    guidedPractice: {
      type: 'array',
      items: {
        type: 'object',
        properties: { q: { type: 'string' }, answer: { type: 'string' } },
        required: ['q', 'answer'],
      },
      description: 'Three questions of increasing difficulty, written out in full with answers.',
    },
    exitCheck: { type: 'string', description: 'A quick formative check with the technique named (thumbs up/down, mini-whiteboard, exit ticket) and the expected answer.' },
    homework: { type: 'string', description: 'Two or three questions written out in full, plus expected effort in minutes.' },
  },
  required: ['day', 'topic', 'minutes', 'objectives', 'periodPlan', 'hook', 'concepts', 'workedExample', 'boardWork', 'misconceptionCheck', 'activity', 'guidedPractice', 'exitCheck', 'homework'],
};

function ctxHeader(c) {
  return `**Board:** ${c.board || 'CBSE'}  |  **Class:** ${c.cls || 'Class 8'}  |  **Subject:** ${c.subject || 'Science'}  |  **Chapter:** ${c.chapter || 'the chapter'}`;
}

function foundationPrompt(c, nDays, period) {
  return `# LESSON PLAN FOUNDATION

${ctxHeader(c)}
**Teaching days:** ${nDays}  |  **Period length:** ${period} minutes

Build the foundation for a ${nDays}-day lesson plan on "${c.chapter}" for ${c.cls} ${c.subject} (${c.board || 'CBSE'}, NCERT).

${COGNITIVE_KEY}

Rules:
- Everything must be specific to THIS chapter. Never write generic pedagogy that would fit any topic.
- Misconceptions must be ones real ${c.cls} students actually hold about this chapter — not invented ones.
- dayPlan must contain exactly ${nDays} entries, numbered 1 to ${nDays}, following this arc: ${DAY_THEMES.slice(0, nDays).join(' -> ')}.
- Each day's topic must be a distinct NCERT sub-topic; together they must cover the whole chapter with no overlap and no gaps.
- Every misconception named in a dayPlan row must be one of the misconceptions you listed.
- No placeholders, no brackets, no "TBD".`;
}

function dayPrompt(c, row, summary, period, nDays, prev, next) {
  const focus = FOCUS_LADDER[(row.day - 1) % FOCUS_LADDER.length];
  const theme = DAY_THEMES[(row.day - 1) % DAY_THEMES.length];
  return `# DAY ${row.day} OF ${nDays} — ${row.topic}

${ctxHeader(c)}
**Theme:** ${theme}  |  **Cognitive Focus:** ${focus}  |  **Period length:** ${period} minutes

## CHAPTER CONTEXT
${summary}

## YOUR PLAN ROW (from the approved chapter plan — teach this and nothing else)
- Topic: ${row.topic}
- Core concepts: ${(row.coreConcepts || []).join('; ')}
- Objective: ${row.objective}
- Misconception to address today: ${row.misconception}
- Pedagogy: ${row.pedagogy}

${prev ? `Yesterday (Day ${row.day - 1}) covered: ${prev}.` : 'This is the first day of the chapter — link back to what students already know from earlier classes.'}
${next ? `Tomorrow (Day ${row.day + 1}) covers: ${next}.` : 'This is the final day — close the loop on the whole chapter.'}

${COGNITIVE_KEY}

## RULES
- Write ONLY Day ${row.day}. Never write another day.
- The six periodPlan phases must sum to EXACTLY ${period} minutes. Guideline split: Introduction 10-15%, Main Teaching 30-35%, Classroom Activity 20-25%, Guided Practice 15-20%, Assessment 8-10%, Homework 3-5%.
- Write the teacher's ACTUAL words for the hook and the concept explanations, not a description of what to say.
- Address the misconception above explicitly in misconceptionCheck.
- Activity materials must be things a low-resource Indian classroom really has. If none are needed, say "None - verbal activity".
- Never invent an NCERT exercise number. Write original questions instead.
- No placeholders, no brackets, no "TBD".`;
}

// Small concurrency pool — the free tier rate-limits, and firing 7 calls at once
// earns a 429 rather than a faster plan.
async function mapPool(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    for (;;) {
      const i = next++;
      if (i >= items.length) return;
      out[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}

export async function generateLessonPlan(context = {}, onProgress = () => {}) {
  const nDays = Math.max(1, Math.min(10, parseInt(context.days, 10) || 5));
  const period = Math.max(25, Math.min(90, parseInt(context.period, 10) || 40));
  const system = SYSTEM_LESSON + languageLine(context);

  onProgress({ phase: 'foundation', done: 0, total: nDays + 1 });
  const foundation = await callStructured({
    system,
    prompt: foundationPrompt(context, nDays, period),
    schema: FOUNDATION_SCHEMA,
    maxTokens: 4096,
  });

  // Trust but verify: the model can return the wrong number of rows.
  let rows = Array.isArray(foundation.dayPlan) ? foundation.dayPlan.slice(0, nDays) : [];
  while (rows.length < nDays) {
    const i = rows.length;
    rows.push({
      day: i + 1,
      topic: `${foundation.title || context.chapter} — part ${i + 1}`,
      coreConcepts: [],
      objective: `Continue building understanding of ${context.chapter}.`,
      misconception: (foundation.misconceptions?.[0]?.myth) || '',
      pedagogy: 'guided explanation with practice',
    });
  }
  rows = rows.map((r, i) => ({ ...r, day: i + 1 }));

  const summary = String(foundation.overview || '').split(/\n\n/)[0].slice(0, 900);

  let completed = 0;
  const days = await mapPool(rows, 4, async (row, i) => {
    const day = await callStructured({
      system,
      prompt: dayPrompt(context, row, summary, period, nDays, rows[i - 1]?.topic, rows[i + 1]?.topic),
      schema: DAY_SCHEMA,
      maxTokens: 4096,
    });
    completed++;
    onProgress({ phase: 'day', done: completed, total: nDays + 1, day: row.day });
    return normaliseDay(day, row, period);
  });

  return {
    title: foundation.title || context.chapter || 'Lesson plan',
    overview: foundation.overview || '',
    ncfGoals: foundation.ncfGoals || [],
    objectives: foundation.objectives || [],
    misconceptions: foundation.misconceptions || [],
    materials: foundation.materials || [],
    days,
  };
}

// The period split is the one thing a teacher will actually check against the clock,
// so repair rounding drift rather than shipping a plan that sums to 38 of 40 minutes.
function normaliseDay(day, row, period) {
  const d = { ...day, day: row.day, topic: day.topic || row.topic, minutes: period };
  let plan = Array.isArray(d.periodPlan) ? d.periodPlan.filter((p) => p && p.phase) : [];
  if (!plan.length) {
    plan = [
      { phase: 'Introduction', minutes: Math.round(period * 0.13) },
      { phase: 'Main Teaching', minutes: Math.round(period * 0.33) },
      { phase: 'Classroom Activity', minutes: Math.round(period * 0.23) },
      { phase: 'Guided Practice', minutes: Math.round(period * 0.18) },
      { phase: 'Assessment', minutes: Math.round(period * 0.09) },
      { phase: 'Homework', minutes: Math.round(period * 0.04) },
    ];
  }
  plan = plan.map((p) => ({ phase: String(p.phase), minutes: Math.max(1, parseInt(p.minutes, 10) || 1) }));
  const drift = period - plan.reduce((a, p) => a + p.minutes, 0);
  if (drift !== 0) {
    // Push the difference into the longest phase (Main Teaching in practice).
    let big = 0;
    plan.forEach((p, i) => { if (p.minutes > plan[big].minutes) big = i; });
    plan[big].minutes = Math.max(1, plan[big].minutes + drift);
  }
  d.periodPlan = plan;
  return d;
}
