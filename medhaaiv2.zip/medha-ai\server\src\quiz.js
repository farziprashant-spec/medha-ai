// Quiz generation.
//
// Two things matter here beyond the prompt:
//  1. Distractor quality. A wrong option that nobody would pick teaches nothing; each
//     one must encode a real student error.
//  2. Positional bias. Models cluster the correct answer at B/C. We shuffle every
//     option set server-side and remap the index, so the answer key is genuinely random.

import { callStructured, languageLine } from './ai.js';

const SYSTEM_QUIZ =
  'You are an expert CBSE/NCERT assessment designer. You write competency-based questions ' +
  'that test understanding and application, not recall of wording. Every question has exactly ' +
  'one defensible correct answer and is age-appropriate for the stated class. ' +
  'You return only the requested JSON — no markdown fences, no commentary.';

const QUIZ_SCHEMA = {
  type: 'object',
  properties: {
    questions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          q: { type: 'string', description: 'The question, standing alone. Never cite a section, exercise, page or figure number.' },
          options: { type: 'array', items: { type: 'string' }, description: 'Exactly 4 options, similar in length and grammatically parallel.' },
          answerIndex: { type: 'integer', description: '0-based index of the correct option' },
          explanation: { type: 'string', description: 'Why the answer is right — not a restatement of it.' },
          difficulty: { type: 'string', description: 'easy | moderate | hard' },
          concept: { type: 'string', description: 'Clean concept name in title case, e.g. "Modes of Nutrition". Never a section number.' },
        },
        required: ['q', 'options', 'answerIndex', 'explanation', 'difficulty', 'concept'],
      },
    },
  },
  required: ['questions'],
};

function difficultyMix(n, startLevel) {
  // Start difficulty shifts the centre of gravity; every quiz still ramps upward.
  const weights = { Easy: [0.5, 0.35, 0.15], Medium: [0.3, 0.45, 0.25], Hard: [0.15, 0.4, 0.45] };
  const w = weights[startLevel] || weights.Medium;
  let easy = Math.round(n * w[0]);
  let moderate = Math.round(n * w[1]);
  let hard = n - easy - moderate;
  if (hard < 0) { moderate += hard; hard = 0; }
  if (moderate < 0) { easy += moderate; moderate = 0; }
  return { easy, moderate, hard };
}

function quizPrompt(c, n, mix) {
  const focus = c.topicFocus ? `**Topic focus:** ${c.topicFocus}` : '**Topic focus:** the whole chapter';
  const goal = c.goal ? `\n**Student goal:** ${c.goal} — bias question style toward this.` : '';
  return `Generate a quiz.

**Class:** ${c.cls || 'Class 8'}   **Subject:** ${c.subject || 'Science'}   **Chapter:** ${c.chapter || 'the chapter'}
**Board:** ${c.board || 'CBSE'} (NCERT)   ${focus}
**Number of questions:** ${n}${goal}

## DIFFICULTY MIX
Produce exactly ${mix.easy} easy, ${mix.moderate} moderate and ${mix.hard} hard questions, in that order.
- easy = direct recall, definitions, identification
- moderate = application to a scenario, cause and effect, comparison, one-step numericals
- hard = multi-concept integration, assertion-reason, case-based, error identification

## QUESTION QUALITY RULES
1. Every question must be answerable from the NCERT chapter itself. No outside facts.
2. Exactly 4 options. answerIndex must point at the genuinely correct one.
3. Every distractor must encode a REAL student error — a misconception someone actually holds.
   Never use "All of the above", "None of the above", "Both A and B", or a joke option.
4. Options must be similar in length and grammatically parallel. Never make the correct
   option the longest or the most detailed — that is a free giveaway.
5. explanation: 1-2 sentences for easy, 2-3 for moderate, 3-4 with reasoning for hard.
   Explain WHY it is right, do not restate the option.
6. concept must be a clean concept name in title case ("Modes of Nutrition"). NEVER a
   section, activity, exercise or page number.
7. Spread concepts across the chapter: at most 2 questions per concept.
8. Never reference section, exercise, page or figure numbers inside the question text.
9. For quantitative subjects include at least 2 questions requiring a real calculation.
10. Write formulas in plain readable text with Unicode (A = pi x r², H₂O, 9.8 m/s²).
    Never use LaTeX, backslash commands or $ delimiters — this app renders plain text.`;
}

const BANNED = /\b(all|none)\s+of\s+the\s+above\b|\bboth\s+[abcd]\s+and\s+[abcd]\b/i;
const SECTION_NUMBER = /^\s*\d+(\.\d+)+\s*$/;

// Drop bad items rather than failing the whole quiz — a 9-question quiz beats an error.
export function validateQuiz(raw, n) {
  const out = [];
  for (const item of raw?.questions || []) {
    if (!item || typeof item.q !== 'string' || !item.q.trim()) continue;
    let options = Array.isArray(item.options) ? item.options.filter((o) => typeof o === 'string' && o.trim()) : [];
    if (options.length !== 4) continue;
    if (options.some((o) => BANNED.test(o))) continue;
    let idx = Number(item.answerIndex);
    if (!Number.isInteger(idx) || idx < 0 || idx > 3) continue;

    // Shuffle to remove positional bias, then find where the answer landed.
    const correct = options[idx];
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }
    idx = options.indexOf(correct);
    if (idx < 0) continue;

    const difficulty = ['easy', 'moderate', 'hard'].includes(String(item.difficulty).toLowerCase())
      ? String(item.difficulty).toLowerCase() : 'moderate';
    let concept = typeof item.concept === 'string' ? item.concept.trim() : '';
    if (!concept || SECTION_NUMBER.test(concept)) concept = 'General';

    out.push({
      q: item.q.trim(),
      options,
      answerIndex: idx,
      explanation: typeof item.explanation === 'string' ? item.explanation.trim() : '',
      difficulty,
      concept,
      marks: { easy: 1, moderate: 2, hard: 3 }[difficulty],
    });
  }
  if (!out.length) throw new Error('The quiz came back empty. Please try again.');
  const questions = out.slice(0, n);
  return { questions, totalMarks: questions.reduce((s, q) => s + q.marks, 0) };
}

export async function generateQuiz(context = {}) {
  const n = Math.max(1, Math.min(50, parseInt(context.count, 10) || 10));
  const mix = difficultyMix(n, context.level);
  const result = await callStructured({
    system: SYSTEM_QUIZ + languageLine(context),
    prompt: quizPrompt(context, n, mix),
    schema: QUIZ_SCHEMA,
    maxTokens: Math.min(16384, 900 + n * 320),
  });
  return validateQuiz(result, n);
}
