// Demo content served while ANTHROPIC_API_KEY is empty, so the whole product —
// chat, lesson plans, quizzes, slides, study plans, class analysis — can be
// previewed with outputs shaped exactly like the real Medha generations.
// The moment a key is added to server/.env, real AI takes over automatically.

export function isDemo() {
  return !process.env.ANTHROPIC_API_KEY;
}

const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const cyc = (arr, i) => arr[i % arr.length];

function bits(context = {}) {
  return {
    ch: context.chapter || 'this chapter',
    cls: context.cls || 'Class 12',
    sub: context.subject || 'Science',
    board: context.board || 'CBSE',
  };
}

/* ---------------- CHAT ---------------- */

const RICH_CHAT = [
  {
    k: ['photosynth', 'calvin', 'chloroplast', 'light reaction', 'stroma', 'thylakoid'],
    md: `### Photosynthesis — the idea in simple words
Plants make their own food. Sunlight, water and carbon dioxide go in; **glucose** (the plant's food) and **oxygen** come out. The green pigment **chlorophyll** catches the light.

### For the exam
- **Definition:** green plants convert CO₂ and H₂O into glucose using light energy, inside the **chloroplast**
- **Light reaction** — on the *thylakoid membrane*: water splits (**photolysis**), oxygen is released, ATP and NADPH form
- **Calvin cycle** — in the *stroma*: CO₂ is fixed by **RuBisCO** → 3-PGA → G3P → RuBP regenerates
- **Equation:** \`6CO₂ + 12H₂O + light → C₆H₁₂O₆ + 6O₂ + 6H₂O\`
- Diagram of the chloroplast is regularly asked — label thylakoid, granum, stroma

### Common mistake
Writing that oxygen comes from CO₂. It comes from the **splitting of water** — examiners specifically check this line.`,
  },
  {
    k: ['diges', 'stomach', 'intestine', 'enzyme', 'pepsin', 'villi'],
    md: `### Digestion — the idea in simple words
Food is broken into pieces small enough for blood to absorb. Mouth → food pipe → stomach → small intestine → large intestine.

### For the exam
- **Mouth:** salivary amylase begins starch digestion
- **Stomach:** HCl + **pepsin** work on proteins (pH 1.5–2.5)
- **Small intestine:** bile emulsifies fats; trypsin, lipase, amylase complete digestion; **villi absorb** the nutrients
- **Large intestine:** water is absorbed
- Enzyme table + labelled alimentary canal diagram = the usual questions

### Common mistake
Saying digestion finishes in the stomach. **Most digestion and nearly all absorption happen in the small intestine.**`,
  },
  {
    k: ['newton', 'motion', 'force', 'inertia', 'momentum'],
    md: `### Newton's three laws — in simple words
- **First:** things keep doing what they are doing until a force changes it (why you jerk forward when a bus brakes)
- **Second:** more force → more acceleration; more mass → less. \`F = ma\`
- **Third:** push a wall, the wall pushes you back equally

### For the exam
- First law **defines inertia**; give the bus/branch-shaking example
- Second law: state it via momentum — \`F = dp/dt\`; SI unit **newton = kg·m/s²**
- Third law: action and reaction act on **different bodies** — write this line, the mark sits there
- Numericals: draw the free-body diagram first, fix a sign convention

### Common mistake
Cancelling action and reaction because they are "equal and opposite" — they never cancel, they act on different bodies.`,
  },
];

export function demoChat(messages = [], context = {}) {
  const { ch, cls, sub, board } = bits(context);
  const lastUser = [...messages].reverse().find((m) => m.role === 'user');
  const q = String(lastUser?.content || 'my doubt').replace(/\s+/g, ' ').slice(0, 140);
  const probe = (q + ' ' + ch).toLowerCase();
  const depth = String(context.depthInstruction || '').toLowerCase();

  const rich = RICH_CHAT.find((r) => r.k.some((k) => probe.includes(k)));
  let body;
  if (rich) {
    body = rich.md;
    if (depth.includes('simply')) body = body.split('### For the exam')[0].trim();
  } else {
    const simple = depth.includes('simply');
    body =
      `### ${ch === 'this chapter' ? 'Your question' : ch} — answering step by step\n` +
      `**You asked:** "${q}"\n\n` +
      `### The idea in simple words\n` +
      `Every topic here comes down to three things — **where** it happens, **what goes in and what comes out**, and **why it matters**. Hold on to those three and the rest of ${ch} builds on top.\n` +
      (simple
        ? `\nThink of one everyday example from home or school and attach the concept to it — that is the fastest way to remember it.`
        : `\n### For the exam (${board} ${cls})\n` +
          `- **Definition** — two lines, in NCERT wording\n` +
          `- **Steps / mechanism** — write in points with arrows, not paragraphs\n` +
          `- **Diagram** — labelled; an unlabelled diagram loses a mark\n` +
          `- **One example** — an everyday example from Indian daily life leaves a strong impression\n\n` +
          `### Common mistake\n` +
          `Writing everything you know instead of what is asked — match the length of your answer to the marks.`);
  }
  return body + `\n\n*(Sample preview — add ANTHROPIC_API_KEY in server/.env and Medha will answer this exact question for real.)*`;
}

/* ---------------- QUIZ ---------------- */

const QBANKS = {
  photo: [
    { q: 'Where does the light reaction of photosynthesis take place?', options: ['Stroma', 'Thylakoid membrane', 'Cell wall', 'Mitochondrial matrix'], answerIndex: 1, explanation: 'Light reactions run on the thylakoid membrane; the Calvin cycle runs in the stroma.' },
    { q: 'The oxygen released during photosynthesis comes from:', options: ['Carbon dioxide', 'Glucose', 'Water', 'Chlorophyll'], answerIndex: 2, explanation: 'Photolysis splits water — the released O₂ comes from H₂O, not CO₂.' },
    { q: 'Which enzyme fixes CO₂ in the Calvin cycle?', options: ['RuBisCO', 'ATP synthase', 'Pepsin', 'Amylase'], answerIndex: 0, explanation: 'RuBisCO carboxylates RuBP — the first step of carbon fixation.' },
    { q: 'How many turns of the Calvin cycle are needed for one glucose molecule?', options: ['2', '4', '6', '8'], answerIndex: 2, explanation: 'Six turns fix six CO₂ — enough for one 6-carbon glucose.' },
  ],
  bio: [
    { q: 'The basic structural and functional unit of life is the:', options: ['Tissue', 'Cell', 'Organ', 'Organism'], answerIndex: 1, explanation: 'All living things are made of cells — the smallest unit that shows life processes.' },
    { q: 'Which organelle is called the powerhouse of the cell?', options: ['Ribosome', 'Nucleus', 'Mitochondrion', 'Golgi body'], answerIndex: 2, explanation: 'Mitochondria release energy as ATP through cellular respiration.' },
    { q: 'The green pigment present in plants is:', options: ['Haemoglobin', 'Chlorophyll', 'Melanin', 'Keratin'], answerIndex: 1, explanation: 'Chlorophyll absorbs light for photosynthesis.' },
    { q: 'Oxygen in blood is carried mainly by:', options: ['White blood cells', 'Platelets', 'Red blood cells', 'Plasma'], answerIndex: 2, explanation: 'Haemoglobin in RBCs binds and transports oxygen.' },
  ],
  phy: [
    { q: 'The SI unit of force is the:', options: ['Joule', 'Newton', 'Watt', 'Pascal'], answerIndex: 1, explanation: '1 newton = 1 kg·m/s².' },
    { q: 'Speed is calculated as:', options: ['Distance × time', 'Distance ÷ time', 'Time ÷ distance', 'Mass × velocity'], answerIndex: 1, explanation: 'Speed is the distance covered per unit time.' },
    { q: '"Every action has an equal and opposite reaction" is Newton\'s:', options: ['First law', 'Second law', 'Third law', 'Law of gravitation'], answerIndex: 2, explanation: 'The third law — the two forces act on different bodies.' },
    { q: 'The SI unit of electric current is the:', options: ['Volt', 'Ohm', 'Ampere', 'Coulomb'], answerIndex: 2, explanation: 'Current is measured in amperes (A).' },
  ],
  chem: [
    { q: 'The chemical formula of water is:', options: ['CO₂', 'H₂O', 'O₂', 'NaCl'], answerIndex: 1, explanation: 'Two hydrogen atoms bonded to one oxygen atom.' },
    { q: 'An acid turns blue litmus paper:', options: ['Blue', 'Green', 'Red', 'Colourless'], answerIndex: 2, explanation: 'Acids turn blue litmus red; bases turn red litmus blue.' },
    { q: 'The smallest particle of an element that keeps its properties is an:', options: ['Molecule', 'Atom', 'Ion', 'Compound'], answerIndex: 1, explanation: 'Atoms are the building blocks of elements.' },
    { q: 'A solid changing directly into gas is called:', options: ['Evaporation', 'Condensation', 'Sublimation', 'Melting'], answerIndex: 2, explanation: 'Camphor and naphthalene sublime — solid to vapour directly.' },
  ],
  math: [
    { q: 'The LCM of 4 and 6 is:', options: ['12', '24', '8', '6'], answerIndex: 0, explanation: '12 is the smallest number divisible by both 4 and 6.' },
    { q: 'The sum of the interior angles of a triangle is:', options: ['90°', '180°', '270°', '360°'], answerIndex: 1, explanation: 'Angle sum property of a triangle: always 180°.' },
    { q: 'If x + 5 = 12, then x equals:', options: ['5', '6', '7', '8'], answerIndex: 2, explanation: 'Subtract 5 from both sides: x = 7.' },
    { q: 'The area of a rectangle is:', options: ['l + b', '2(l + b)', 'l × b', 'l²'], answerIndex: 2, explanation: 'Area = length × breadth; 2(l+b) is the perimeter.' },
  ],
  gen: [
    { q: 'The best first step when starting a new chapter is to:', options: ['Jump straight to the exercises', 'Read the summary and headings first', 'Memorise every line', 'Skip the diagrams'], answerIndex: 1, explanation: 'A quick map of headings and the summary tells you what to look for while reading.' },
    { q: 'NCERT intext questions matter because they:', options: ['Are just decoration', 'Test the exact concept you just read', 'Never appear in exams', 'Are only for teachers'], answerIndex: 1, explanation: 'Board papers and competitive exams pick directly from intext and exercise questions.' },
    { q: 'A labelled diagram in a board answer usually earns:', options: ['Nothing extra', 'Negative marks', 'Dedicated marks', 'Marks only in Maths'], answerIndex: 2, explanation: 'Many answers carry 1–2 marks specifically for a correct labelled diagram.' },
    { q: 'The most effective revision technique before an exam is:', options: ['One all-night study session', 'Spaced revision with self-testing', 'Reading notes once silently', 'Only watching videos'], answerIndex: 1, explanation: 'Short, spaced sessions with active recall beat cramming every time.' },
  ],
};

export function demoQuiz(context = {}) {
  const { ch, sub } = bits(context);
  const n = clamp(parseInt(context.count, 10) || 10, 1, 50);
  const probe = ch.toLowerCase();
  const s = sub.toLowerCase();

  const order = [];
  if (/photo|calvin|chloro/.test(probe)) order.push(...QBANKS.photo);
  if (/bio|evs|science/.test(s)) order.push(...QBANKS.bio);
  if (/phy|science/.test(s)) order.push(...QBANKS.phy);
  if (/chem|science/.test(s)) order.push(...QBANKS.chem);
  if (/math/.test(s)) order.push(...QBANKS.math);
  order.push(...QBANKS.gen, ...QBANKS.bio, ...QBANKS.phy, ...QBANKS.chem, ...QBANKS.math);

  const seen = new Set();
  const uniq = order.filter((q) => (seen.has(q.q) ? false : seen.add(q.q)));
  const questions = [];
  for (let i = 0; i < n; i++) {
    const base = cyc(uniq, i);
    questions.push(i < uniq.length ? base : { ...base, q: base.q + ' (revision)' });
  }
  return { questions };
}

/* ---------------- SLIDES ---------------- */

export function demoSlides(context = {}) {
  const { ch, cls, sub } = bits(context);
  const n = clamp(parseInt(context.slides, 10) || 12, 4, 20);
  const concepts = [
    { h: `The core idea of ${ch}`, b: ['Definition in NCERT words', 'Why this matters for your exam', 'The one line to remember'], note: 'Introduce the concept slowly; ask two students to repeat it in their own words.' },
    { h: 'How it works — step by step', b: ['Step 1 → Step 2 → Step 3 with arrows', 'Where each step happens', 'What goes in, what comes out'], note: 'Build the flow on the board as you speak; students copy the arrows.' },
    { h: 'Key terms & definitions', b: ['3–4 terms the examiner expects', 'Each in one NCERT-style line', 'Underline them in the textbook'], note: 'Have students underline these in their own books right now.' },
    { h: 'One everyday example', b: ['An example from daily Indian life', 'Connect it back to the definition', 'Ask the class for one more example'], note: 'Localise the example to your town — attention doubles.' },
    { h: 'Where students go wrong', b: ['The classic misconception', 'The correct idea, side by side', 'The one-line fix for exams'], note: 'State the misconception first, then let students spot the error.' },
  ];
  const slides = [
    { heading: ch, bullets: [`${cls} · ${sub}`, 'NCERT-aligned teaching deck'], speakerNotes: 'Welcome the class, state the chapter and one clear goal for today.' },
    { heading: 'What we will learn today', bullets: [`The central concept of ${ch}`, 'The steps and where they happen', 'One real-life connection', 'What the exam asks from this chapter'], speakerNotes: 'Read the objectives aloud — students should know what "done" looks like.' },
  ];
  for (let i = 0; slides.length < n - 2; i++) {
    const c = cyc(concepts, i);
    slides.push({ heading: c.h, bullets: c.b, speakerNotes: c.note });
  }
  slides.push(
    { heading: 'Quick check', bullets: ['Q1. One-line definition?', 'Q2. Which step comes first?', 'Q3. Spot the error in this statement'], speakerNotes: 'Cold-call gently; the goal is to hear the class say the key line correctly.' },
    { heading: 'Recap & homework', bullets: ['The one line to remember', `NCERT intext questions of ${ch}`, 'Draw and label the main diagram'], speakerNotes: 'End by repeating the single most important line of the day.' },
  );
  return { title: ch, slides: slides.slice(0, Math.max(4, n)) };
}

/* ---------------- STUDY PLAN ---------------- */

export function demoStudyPlan(context = {}) {
  const { ch } = bits(context);
  const dur = String(context.duration || '1 Week');
  const hours = parseInt(context.hoursPerDay, 10) || 4;
  const nDays = /day/i.test(dur) && !/week|month/i.test(dur) ? 1 : /month/i.test(dur) ? 10 : /week/i.test(dur) ? 7 : 5;
  const titles = [
    ['Read & map the chapter', ['Read the chapter once with a highlighter', 'Make a one-page map of headings', 'List every NCERT keyword']],
    ['Deep dive — first half', ['Study the first half slowly with the diagram', 'Write definitions in your own words', 'Solve the intext questions of this part']],
    ['Deep dive — second half', ['Finish the remaining sections', 'Link them back to the first half', 'Solve the remaining intext questions']],
    ['Practice NCERT questions', ['Solve all exercise questions in writing', 'Mark the ones you got wrong', 'Redo the wrong ones from scratch']],
    ['Diagrams & memory work', ['Draw every diagram twice with labels', 'Make a formula/keyword flashcard set', 'Recite the key lines aloud']],
    ['Mock test & gap-fixing', ['Take a 30-minute self-test', 'Score honestly with the answer key', 'Re-study only the weak spots']],
    ['Final revision', ['Revise the one-page map', 'One quick round of flashcards', 'Attempt one previous-year question']],
  ];
  const days = [];
  for (let i = 0; i < nDays; i++) {
    const t = cyc(titles, i);
    days.push({ day: `Day ${i + 1}`, title: i === nDays - 1 && nDays > 2 ? 'Final revision' : t[0], tasks: (i === nDays - 1 && nDays > 2 ? titles[6][1] : t[1]).map((x) => x.replace('the chapter', `"${ch}"`)), estMinutes: clamp(hours, 1, 10) * 60 });
  }
  return { days };
}

/* ---------------- LESSON PLAN ---------------- */

function periodPhases(P, activity) {
  const spec = [
    ['Introduction & recap', 0.15],
    ['Main Teaching', 0.35],
    [`Classroom Activity: "${activity}"`, 0.3],
    ['Guided Practice', 0.12],
    ['Assessment (exit check)', 0.05],
    ['Homework briefing', 0.03],
  ];
  const mins = spec.map(([, f]) => Math.max(1, Math.round(P * f)));
  const diff = P - mins.reduce((a, b) => a + b, 0);
  mins[1] += diff; // absorb rounding into Main Teaching
  return spec.map(([phase], i) => ({ phase, minutes: mins[i] }));
}

export function demoLessonPlan(context = {}) {
  const { ch, cls, sub, board } = bits(context);
  const N = clamp(parseInt(context.days, 10) || 5, 1, 10);
  const P = clamp(parseInt(context.period, 10) || 40, 25, 90);

  const dayTopics = [
    'Introduction — activating prior knowledge',
    'Core concept I — the main idea, step by step',
    'Core concept II — processes, diagrams and examples',
    'Application — practice, numericals and real life',
    'Activity day — misconceptions and discussion',
    'NCERT questions & peer teach-back',
  ];
  const hooks = [
    `Ask: "Where did you last notice ${ch} in real life — at home, on the way to school, in the kitchen?" Take three answers before opening the book.`,
    `Write one deliberately wrong statement about ${ch} on the board and ask the class to prove it wrong.`,
    `Show the chapter's main diagram with its labels covered — the class guesses each label before the lesson begins.`,
    `Read out one previous-year board question on ${ch} and ask: "By the end of today you will be able to answer this."`,
    `Two-minute pair talk: each student tells their partner one thing they already know and one thing they want to know about ${ch}.`,
  ];
  const activities = [
    'Think-pair-share on the hook question',
    'Label-the-diagram relay on the board',
    'Card-sort — arrange the steps in the correct order',
    'Two-minute teach-back in pairs',
    'Real-life example hunt around the classroom',
  ];

  const days = [];
  for (let i = 0; i < N; i++) {
    const last = i === N - 1 && N > 1;
    days.push({
      day: i + 1,
      topic: last ? 'Revision, assessment & closing the loop' : cyc(dayTopics, i),
      minutes: P,
      objectives: last
        ? [`Recall the full arc of ${ch} without the book (NCF C-1.2)`, 'Answer mixed recall + application questions in exam format', 'Identify their own weakest sub-topic for self-study']
        : [`Explain today's portion of ${ch} in their own words (NCF C-1.2)`, 'Connect the concept to one everyday example', 'Answer two exam-style questions on today\'s portion'],
      periodPlan: periodPhases(P, cyc(activities, i)),
      hook: cyc(hooks, i),
      boardWork: `Chapter map of "${ch}" with today's branch highlighted; key terms of the day listed on the left with one-line meanings.`,
      activity: cyc(activities, i) + ' — 4 groups, 2 minutes to present.',
      exitCheck: 'Three-question slip: one recall, one reasoning, one application from today\'s portion. Collect and scan while students pack up.',
      homework: last ? `One previous-year board question on ${ch}, answered in exam format.` : `NCERT intext questions for today's section of "${ch}".`,
    });
  }

  return {
    title: ch,
    overview:
      `This ${N}-day plan takes ${cls} through "${ch}" (${sub}, ${board}) from prior knowledge to exam-ready answers. Each ${P}-minute period follows the same rhythm — a short hook, focused teaching, one hands-on activity, guided practice and a three-question exit check — so students always know what "done" looks like.\n\n` +
      `The competencies progress across the week: recall and vocabulary first, then explanation and diagrams, then application to everyday contexts, and finally mixed assessment. Misconceptions are surfaced deliberately on the activity day rather than left to appear in the exam.`,
    ncfGoals: [
      `CG-1: Understands core concepts of ${sub} through inquiry — C-1.2: Explains observations using evidence and correct NCERT terminology.`,
      `CG-4: Applies learning to new situations — C-4.3: Connects "${ch}" to everyday contexts and solves related problems.`,
      'CG-7: Communicates learning effectively — C-7.1: Presents ideas using correct terms, labelled diagrams and structured answers.',
    ],
    objectives: [
      { text: `State the key terms and definitions of ${ch} in NCERT wording`, bloom: 'Remember' },
      { text: `Explain the central concept of ${ch} with one everyday example`, bloom: 'Understand' },
      { text: `Apply the concept to NCERT exercise questions and simple problems`, bloom: 'Apply' },
      { text: `Analyse how ${ch} connects to earlier chapters and daily life`, bloom: 'Analyse' },
      { text: 'Evaluate common wrong statements about the topic and justify the correction', bloom: 'Evaluate' },
    ],
    misconceptions: [
      { myth: `"${ch}" only needs to be memorised the night before the exam.`, fact: 'Board questions test application. Build understanding in class first; memory work then takes a fraction of the time.' },
      { myth: 'Diagrams are optional if the written answer is good.', fact: 'Labelled diagrams regularly carry dedicated marks — practise them as seriously as definitions.' },
      { myth: 'NCERT intext questions can be skipped in favour of guidebooks.', fact: 'Board papers and competitive exams lift questions directly from NCERT intext and exercises — do them first.' },
    ],
    materials: [
      `NCERT ${cls} ${sub} textbook — "${ch}"`,
      'Blackboard chapter map + coloured chalk',
      'Printed three-question exit slips (one per student per day)',
      'Chart, model or phone visual of the chapter\'s main diagram',
      'Card-sort strips for the activity day',
    ],
    days,
  };
}

/* ---------------- CLASS ANALYSIS ---------------- */

export function demoAnalysis(context = {}) {
  const { ch, cls, sub } = bits(context);
  return {
    notes:
      `## ${ch} — structured class notes\n\n### What the class covered\n- The central idea of ${ch}, introduced through a real-life hook\n- Step-by-step mechanism with the main diagram built on the board\n- Key NCERT terms with one-line meanings\n- Two exam-style questions solved together\n\n### Key definitions\n- Each key term was written in NCERT wording and underlined in the textbook\n- The main diagram was drawn and labelled twice\n\n### Exam pointers from the class\n- The definition + diagram combination is the most frequently asked pattern\n- One previous-year question was flagged for homework`,
    insights: [
      `The class stayed most engaged during the real-life example — reuse that entry point next period`,
      'Roughly a third of students hesitated on the key definition — quick recap needed tomorrow',
      'The labelled diagram was the weakest area in the exit check',
      `Students connected ${ch} well to the previous chapter when prompted`,
      'Question pace: two exam-style questions fit comfortably in one period',
      `Suggested next step: a 5-question adaptive quiz on ${ch} (${cls} ${sub})`,
    ],
    actionItems: [
      'Revise the key definition aloud twice before the next class',
      'Draw and label the main diagram once from memory',
      `Solve the NCERT intext questions of "${ch}"`,
      'Attempt the flagged previous-year question in exam format',
      'Note one doubt to ask at the start of the next period',
    ],
    summary:
      `Today's class took "${ch}" from a real-life hook to exam-ready notes: the mechanism was built step by step on the board, key NCERT terms were fixed in context, and two exam-style questions were solved together. The exit check shows the definition has landed for most students while the labelled diagram needs one more pass.\n\nTomorrow: a two-minute diagram recap, then move to the application section — and assign the auto-generated quiz below for practice.`,
  };
}

export function demoStructured(type, context = {}) {
  switch (type) {
    case 'quiz': return demoQuiz(context);
    case 'slides': return demoSlides(context);
    case 'studyPlan': return demoStudyPlan(context);
    case 'lessonPlan': return demoLessonPlan(context);
    case 'classAnalysis': {
      const a = demoAnalysis(context);
      return { ...a, quiz: demoQuiz({ ...context, count: 5 }).questions.map(({ q, options, answerIndex }) => ({ q, options, answerIndex })) };
    }
    default: throw new Error(`Unknown generation type: ${type}`);
  }
}
