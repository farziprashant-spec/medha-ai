import Anthropic from '@anthropic-ai/sdk';
import { isDemo, demoChat, demoStructured } from './demo.js';

export { isDemo };

let client = null;
function getClient() {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error('ANTHROPIC_API_KEY is not set in server/.env');
  }
  if (!client) client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return client;
}

const MODEL = () => process.env.ANTHROPIC_MODEL || 'claude-fable-5';

const SYSTEM_BASE = `You are Medha, an AI teaching assistant for Indian school students and teachers (CBSE/ICSE/state boards).
Explanations should be clear, exam-focused, and appropriate for the student's class level. Use simple language first,
then precise technical detail. When board/class/subject/chapter context is given, tailor content specifically to it —
never fall back to a generic or unrelated example topic.`;

export async function streamChat({ messages, context }, onDelta) {
  if (isDemo()) {
    // No API key yet — stream a realistic sample answer so the product can be previewed.
    const full = demoChat(messages, context);
    const words = full.split(/(\s+)/);
    for (let i = 0; i < words.length; i += 4) {
      onDelta(words.slice(i, i + 4).join(''));
      await new Promise((r) => setTimeout(r, 18));
    }
    return full;
  }
  const anthropic = getClient();
  const contextLine = context
    ? `Student context: board=${context.board || 'n/a'}, class=${context.cls || 'n/a'}, subject=${context.subject || 'n/a'}, chapter=${context.chapter || 'n/a'}.`
    : '';
  const depthLine = context?.depthInstruction ? `\n${context.depthInstruction}` : '';
  const stream = anthropic.messages.stream({
    model: MODEL(),
    max_tokens: 1024,
    system: `${SYSTEM_BASE}\n${contextLine}${depthLine}`,
    messages: messages.map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.content })),
  });
  stream.on('text', (delta) => onDelta(delta));
  const final = await stream.finalMessage();
  return final.content.map((b) => (b.type === 'text' ? b.text : '')).join('');
}

const SCHEMAS = {
  quiz: {
    description: 'A set of multiple-choice questions with the correct answer and a short explanation.',
    input_schema: {
      type: 'object',
      properties: {
        questions: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              q: { type: 'string' },
              options: { type: 'array', items: { type: 'string' }, minItems: 4, maxItems: 4 },
              answerIndex: { type: 'integer', minimum: 0, maximum: 3 },
              explanation: { type: 'string' },
            },
            required: ['q', 'options', 'answerIndex', 'explanation'],
          },
        },
      },
      required: ['questions'],
    },
  },
  studyPlan: {
    description: 'A day-wise study plan.',
    input_schema: {
      type: 'object',
      properties: {
        days: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              day: { type: 'string' },
              title: { type: 'string' },
              tasks: { type: 'array', items: { type: 'string' } },
              estMinutes: { type: 'integer' },
            },
            required: ['day', 'title', 'tasks', 'estMinutes'],
          },
        },
      },
      required: ['days'],
    },
  },
  slides: {
    description: 'A slide-by-slide presentation outline.',
    input_schema: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        slides: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              heading: { type: 'string' },
              bullets: { type: 'array', items: { type: 'string' } },
              speakerNotes: { type: 'string' },
            },
            required: ['heading', 'bullets', 'speakerNotes'],
          },
        },
      },
      required: ['title', 'slides'],
    },
  },
  lessonPlan: {
    description: 'A complete NEP-2020-aligned lesson plan for one textbook chapter: chapter overview with NCF competency progression, Bloom-tagged learning objectives, common misconceptions, materials, and a day-wise breakdown where every day has its own objectives, a minute-by-minute period plan, a localised hook, board work, one classroom activity, an exit check and homework.',
    input_schema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Chapter title as the textbook names it' },
        overview: {
          type: 'string',
          description: '2–3 paragraph overview of the chapter: what it covers, why it matters for this class, and how the competencies progress across the plan.',
        },
        ncfGoals: {
          type: 'array',
          items: { type: 'string' },
          description: 'NCF curricular goals and competencies this plan develops, each like "CG-5: Understands the Indian Constitution … — C-5.4: Analyses the basic features of a democracy …"',
        },
        objectives: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              text: { type: 'string' },
              bloom: { type: 'string', description: "Bloom's level: Remember, Understand, Apply, Analyse, Evaluate or Create" },
            },
            required: ['text', 'bloom'],
          },
          description: 'Chapter-level learning objectives, each tagged with its Bloom’s Taxonomy level.',
        },
        misconceptions: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              myth: { type: 'string', description: 'What students commonly get wrong' },
              fact: { type: 'string', description: 'The correction, and how to address it in class' },
            },
            required: ['myth', 'fact'],
          },
        },
        materials: { type: 'array', items: { type: 'string' }, description: 'Teaching aids and materials, low-cost and realistic for an Indian classroom.' },
        days: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              day: { type: 'integer' },
              topic: { type: 'string', description: 'NCERT topic taught this day' },
              minutes: { type: 'integer', description: 'Period length in minutes' },
              objectives: { type: 'array', items: { type: 'string' }, description: "Today's objectives; map to NCF competency codes like (NCF C-1.2) where sensible" },
              periodPlan: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    phase: { type: 'string', description: 'e.g. Introduction, Main Teaching, Classroom Activity: "…", Guided Practice, Assessment, Homework' },
                    minutes: { type: 'integer' },
                  },
                  required: ['phase', 'minutes'],
                },
                description: 'Minute-by-minute period plan; phase minutes must sum to the period length.',
              },
              hook: { type: 'string', description: 'A 1–2 line opening hook rooted in everyday Indian life for this class level.' },
              boardWork: { type: 'string', description: 'What to draw or write on the board this day.' },
              activity: { type: 'string', description: 'One hands-on or discussion activity with concrete steps.' },
              exitCheck: { type: 'string', description: 'A 3–5 minute exit check that verifies the day’s objective.' },
              homework: { type: 'string' },
            },
            required: ['day', 'topic', 'minutes', 'objectives', 'periodPlan', 'hook', 'boardWork', 'activity', 'exitCheck', 'homework'],
          },
        },
      },
      required: ['title', 'overview', 'ncfGoals', 'objectives', 'misconceptions', 'materials', 'days'],
    },
  },
  classAnalysis: {
    description: 'Structured analysis of a class transcript or topic: notes, insights, a short quiz, action items and a summary.',
    input_schema: {
      type: 'object',
      properties: {
        notes: { type: 'string', description: 'Structured class notes, markdown-ish plain text with headings.' },
        insights: { type: 'array', items: { type: 'string' } },
        quiz: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              q: { type: 'string' },
              options: { type: 'array', items: { type: 'string' }, minItems: 4, maxItems: 4 },
              answerIndex: { type: 'integer', minimum: 0, maximum: 3 },
            },
            required: ['q', 'options', 'answerIndex'],
          },
        },
        actionItems: { type: 'array', items: { type: 'string' } },
        summary: { type: 'string' },
      },
      required: ['notes', 'insights', 'quiz', 'actionItems', 'summary'],
    },
  },
};

export async function generateStructured({ type, context }) {
  const schema = SCHEMAS[type];
  if (!schema) throw new Error(`Unknown generation type: ${type}`);
  if (isDemo()) {
    await new Promise((r) => setTimeout(r, 900)); // small delay so the progress steps read naturally
    return demoStructured(type, context);
  }
  const anthropic = getClient();

  const contextDesc = Object.entries(context || {})
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n');

  const lessonDays = parseInt(context?.days, 10) || 5;
  const lessonPeriod = parseInt(context?.period, 10) || 40;
  const extraInstr = {
    quiz: context?.count ? `Generate exactly ${context.count} questions${context.level ? ` at ${context.level} difficulty` : ''}.` : '',
    slides: context?.slides ? `Generate exactly ${context.slides} slides.` : '',
    studyPlan: 'Split the plan into a sensible number of days/sessions based on the duration given.',
    lessonPlan:
      `Build exactly ${lessonDays} teaching days. Every period is ${lessonPeriod} minutes and each day's periodPlan phase minutes must sum to exactly ${lessonPeriod}. ` +
      'Keep hooks and activity examples local to everyday Indian life. Reference NCF competency codes in ncfGoals and in day objectives where sensible, and tag every chapter objective with its Bloom’s level.',
  }[type] || '';

  const response = await anthropic.messages.create({
    model: MODEL(),
    max_tokens: type === 'lessonPlan' ? 8192 : 4096,
    system: SYSTEM_BASE,
    messages: [
      {
        role: 'user',
        content: `Generate a "${type}" for this context:\n${contextDesc}\n${extraInstr}\n\nCall the emit_result tool with the result.`,
      },
    ],
    tools: [{ name: 'emit_result', description: schema.description, input_schema: schema.input_schema }],
    tool_choice: { type: 'tool', name: 'emit_result' },
  });

  const toolUse = response.content.find((b) => b.type === 'tool_use');
  if (!toolUse) throw new Error('Model did not return structured output');
  return toolUse.input;
}
