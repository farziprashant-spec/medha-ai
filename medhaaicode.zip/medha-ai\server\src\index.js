import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import cors from 'cors';
import { authRouter } from './routes/auth.js';
import { generateRouter } from './routes/generate.js';

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '2mb' }));

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', authRouter);
app.use('/api/generate', generateRouter);

// Serve the frontend for local dev (only the app files — never the server dir or .env)
const webRoot = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
app.get('/', (req, res) => res.sendFile(path.join(webRoot, 'index.html')));
for (const f of ['index.html', 'manifest.json', 'sw.js']) {
  app.get(`/${f}`, (req, res) => res.sendFile(path.join(webRoot, f)));
}
app.use('/icons', express.static(path.join(webRoot, 'icons')));

const port = process.env.PORT || 8787;
app.listen(port, () => console.log(`Medha AI server listening on http://localhost:${port}`));
