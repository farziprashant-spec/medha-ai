import { Router } from 'express';
import { normalizePhone, generateAndStoreOtp, sendOtpSms, verifyOtp, verifyGoogleIdToken, issueToken, authMiddleware } from '../auth.js';
import { findUserByPhone, findUserByEmail, createUser, createGoogleUser, findUserById, updateUser } from '../db.js';

export const authRouter = Router();

function publicUser(user) {
  return {
    id: user.id,
    phone: user.phone && user.phone.startsWith('g:') ? null : user.phone,
    email: user.email || null,
    name: user.name,
    role: user.role,
    coins: user.coins,
    avatar: user.avatar || null,
  };
}

function applyRole(user, role) {
  if (role && (role === 'Teacher' || role === 'Student') && role !== user.role) {
    return updateUser(user.id, { role });
  }
  return user;
}

authRouter.post('/request-otp', async (req, res) => {
  const phone = normalizePhone(req.body.phone);
  if (!phone) return res.status(400).json({ error: 'invalid_phone' });

  const code = generateAndStoreOtp(phone);
  try {
    const result = await sendOtpSms(phone, code);
    res.json({ ok: true, devOtp: result.dev ? code : undefined });
  } catch (err) {
    res.status(500).json({ error: 'sms_send_failed', message: err.message });
  }
});

authRouter.post('/verify-otp', (req, res) => {
  const phone = normalizePhone(req.body.phone);
  const code = String(req.body.code || '');
  if (!phone || !code) return res.status(400).json({ error: 'invalid_request' });

  const result = verifyOtp(phone, code);
  if (!result.ok) return res.status(400).json({ error: result.reason });

  let user = findUserByPhone(phone);
  if (!user) user = createUser(phone);
  user = applyRole(user, req.body.role);

  const token = issueToken(user);
  res.json({ token, user: publicUser(user) });
});

// Real Google Sign-In: the frontend sends the Google Identity Services ID token.
authRouter.post('/google', async (req, res) => {
  const credential = req.body.credential;
  if (!credential) return res.status(400).json({ error: 'missing_credential' });

  try {
    const info = await verifyGoogleIdToken(credential);
    let user = findUserByEmail(info.email);
    if (!user) user = createGoogleUser({ email: info.email, name: info.name, sub: info.sub, avatar: info.picture });
    user = applyRole(user, req.body.role);
    if (info.name && !user.name) user = updateUser(user.id, { name: info.name });

    const token = issueToken(user);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    res.status(401).json({ error: 'google_auth_failed', message: err.message });
  }
});

// Dev-mode Google login: lets "Continue with Google" work before a real
// GOOGLE_CLIENT_ID is configured, mirroring OTP_DEV_MODE. Disable with GOOGLE_DEV_MODE=false.
authRouter.post('/google-dev', (req, res) => {
  if (process.env.GOOGLE_DEV_MODE === 'false') {
    return res.status(400).json({ error: 'google_dev_disabled', message: 'Set GOOGLE_CLIENT_ID in server/.env and reload to use real Google Sign-In.' });
  }
  const role = req.body.role === 'Student' ? 'Student' : 'Teacher';
  const email = `demo.${role.toLowerCase()}@medha.ai`;

  let user = findUserByEmail(email);
  if (!user) user = createGoogleUser({ email, name: `${role} (Google)`, sub: `dev-${role.toLowerCase()}` });
  user = applyRole(user, role);

  const token = issueToken(user);
  res.json({ token, user: publicUser(user), dev: true });
});

authRouter.get('/me', authMiddleware, (req, res) => {
  const user = findUserById(req.userId);
  if (!user) return res.status(404).json({ error: 'not_found' });
  res.json({ user: publicUser(user) });
});
