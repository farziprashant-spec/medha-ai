import { Router } from 'express';
import { authMiddleware } from '../auth.js';
import { streamChat, generateStructured, isDemo } from '../ai.js';
import { db } from '../db.js';

export const generateRouter = Router();

generateRouter.post('/chat', authMiddleware, async (req, res) => {
  const { messages, context } = req.body;
  if (!Array.isArray(messages) || !messages.length) {
    return res.status(400).json({ error: 'messages_required' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  try {
    const full = await streamChat({ messages, context }, (delta) => {
      res.write(`data: ${JSON.stringify({ delta })}\n\n`);
    });
    res.write(`data: ${JSON.stringify({ done: true, full, demo: isDemo() })}\n\n`);
    res.end();
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
});

generateRouter.post('/', authMiddleware, async (req, res) => {
  const { type, context } = req.body;
  if (!type) return res.status(400).json({ error: 'type_required' });

  try {
    const result = await generateStructured({ type, context });
    db.prepare('INSERT INTO generations (user_id, type, context_json, result_json) VALUES (?, ?, ?, ?)')
      .run(req.userId, type, JSON.stringify(context || {}), JSON.stringify(result));
    res.json({ result, demo: isDemo() });
  } catch (err) {
    res.status(500).json({ error: 'generation_failed', message: err.message });
  }
});
